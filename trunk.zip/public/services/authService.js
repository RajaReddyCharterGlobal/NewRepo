/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular.module('helpDesk')
        .service('AuthService', function ($q, $http, API_ENDPOINT, $rootScope) {
            var LOCAL_TOKEN_KEY = 'yourTokenKey';
            var isAuthenticated = false;
            var authToken;
            var userObj = {};
            function loadUserCredentials() {
                //console.log('load credentials function called');
                var storedVal = window.localStorage.getItem(LOCAL_TOKEN_KEY);
                if (storedVal) {
                    userObj = JSON.parse(storedVal);
                    //console.log(userObj);
                    if (userObj && userObj.token) {
                        //console.log('entered if condition', userObj);
                        useCredentials(userObj);
                    }
                }

            }

            function storeUserCredentials(user) {
                //console.log('user details stored',user);
                var userStrg = JSON.stringify(user);
                window.localStorage.setItem(LOCAL_TOKEN_KEY, userStrg);
                useCredentials(user);
            }

            function useCredentials(user) {
                isAuthenticated = true;
                authToken = user.token;
                $rootScope.userObj = user.user;
                // Set the token as header for your requests!
                $http.defaults.headers.common.Authorization = authToken;
            }

            function destroyUserCredentials() {
                authToken = undefined;
                isAuthenticated = false;
                $http.defaults.headers.common.Authorization = undefined;
                window.localStorage.removeItem(LOCAL_TOKEN_KEY);
                console.log('destroyed session now check for connection');
            }

            var register = function (user) {
                return $q(function (resolve, reject) {
                    $http.post(API_ENDPOINT.url + '/signup', user).then(function (result) {
                        if (result.data.success) {
                            resolve(result.data.msg);
                        } else {
                            reject(result.data.msg);
                        }
                    });
                });
            };

            var login = function (user) {
                //console.log(user);
                var dfd = $q.defer();
                //console.log('login service called');
                $http.post(API_ENDPOINT.url + '/user/authenticate', user).then(function (result) {
                    if (result.data.success) {
                        //console.log(result.data.success);
                        //console.log('token received as',result.data);
                        //console.log(result.data);
                        //console.log('data received',result.data.user);
                        storeUserCredentials(result.data);
                        dfd.resolve(result.data.msg);
                    } else {
                        //console.log(result.data.msg);
                        dfd.reject(result.data.msg);
                    }
                });
                //console.log(dfd.promise);
                return dfd.promise;
            };
            var resetPwd=function(email){
                var dfd = $q.defer();
                $http.post(API_ENDPOINT.url + '/user/reset-password', email).then(function (result) {
                    console.log(result.data);
                    if (result.data.success) {
                        //storeUserCredentials(result.data);
                        dfd.resolve(result.data.msg);
                    } else {
                        //console.log(result.data.msg);
                        dfd.reject(result.data.reason);
                    }
                });
                return dfd.promise;
            };
            var logout = function () {
                destroyUserCredentials();
            };

            loadUserCredentials();

            return {
                login: login,
                register: register,
                logout: logout,
                resetPwd:resetPwd,
                isAuthenticated: function () {
                    return isAuthenticated;
                },
            };
        })

        .factory('AuthInterceptor', function ($rootScope, $q, AUTH_EVENTS) {
            return {
                responseError: function (response) {
                    $rootScope.$broadcast({
                        401: AUTH_EVENTS.notAuthenticated,
                    }[response.status], response);
                    return $q.reject(response);
                }
            };
        })
        .config(function ($httpProvider) {
            $httpProvider.interceptors.push('AuthInterceptor');
        });