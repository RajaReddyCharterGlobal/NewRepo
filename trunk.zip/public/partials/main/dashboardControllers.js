/**
 * Created by Pkp on 5/15/2016.
 */
angular.module('helpDesk')
        .controller('dashboardCtrl', ['$scope', '$window', 'httpService', '$filter', '$location', 'ticketsManager',
            function ($scope, $window, httpService, $filter, $location, ticketsManager) {

                $scope.initProcess = function () {
                    $scope.loadTickets();
                }
                $scope.loadTickets = function () {
                    ticketsManager.loadAllTickets().then(function (tickets) {
                        $scope.data = tickets;
                        //console.log($scope.data);
                        $scope.TotalTickets = tickets.length;
                        $scope.loadSolvedTickets(tickets);
                        //$scope.loadTatExceededTickets(tickets);
                        //console.log('total Count',$scope.TotalTickets);
                    }, function (error) {
                        console.log(error);
                    })
                }
                $scope.SolvedCount = 0;
                $scope.TimeExceededTicketsCounts = 0;
                $scope.TimeExceededTickets = [];
                $scope.PendingTickets = [];
                $scope.RequestTicketsCount = 0;
                $scope.IssueTicketsCount = 0;
                $scope.loadSolvedTickets = function (tickets) {
                    if (tickets) {
                        //console.log(tickets);
                        angular.forEach(tickets, function (value, key) {
                            //console.log(value);
//                            console.log(value.status);
                            if (value.status == 'Closed') {
                                $scope.SolvedCount = $scope.SolvedCount + 1;
                            }
                            //console.log(value.issue_type_cat_1);
                            if (value.issue_type_cat_1 == 'issue') {
                                $scope.IssueTicketsCount = $scope.IssueTicketsCount + 1;
                            }
                            if (value.issue_type_cat_1 == 'request') {
                                $scope.RequestTicketsCount = $scope.RequestTicketsCount + 1;
                            }
                            if (value.status !== 'New' && value.status !== 'Open' && value.status !== 'Closed') {
                                //console.log(value.status);
                                $scope.PendingTickets.push(value);
                            }
                            if (value.master_st !== 0 && value.status !== 'Closed'&&value.status !== 'New') {
                                //console.log('value.master_st',value.master_st);
                                //$scope.TatExceeededTicketsCount = $scope.TatExceeededTicketsCount + 1;
                                //console.log();
                                var StartedAt = value.master_st;
                                var Current_Date = Date.now();
                                var tat_time = value.tat_time || 1;
                                //console.log('tat time set/default', tat_time);
                                var startDateFormated = new Date(StartedAt);
                                //console.log('actually started at', startDateFormated);
                                var shouldEndAt=startDateFormated.setHours(startDateFormated.getHours() + tat_time);
                                var shouldEndAtFormated=new Date(shouldEndAt);
//                                console.log('it should End at', shouldEndAtFormated);
//                                console.log('current time ',Date(Current_Date));
                                if (Current_Date>shouldEndAt) {
                                    $scope.TimeExceededTicketsCounts = $scope.TimeExceededTicketsCounts + 1;
                                    $scope.TimeExceededTickets.push(value);
                                    //console.log('warning exceeded! ticket ID',value.ticketID);
                                } else {
                                    console.log('Not Exceeded!');
                                }
                                

//                                var deadLineAt =
//                                        console.log(Math.floor(Date.now()));
                            }

                            //this.push(key + ': ' + value);
                        });
                    }
                }
                
                 $scope.$on('NewTicket', function (event, ticket) {
                     console.log('realtime message dashboard',ticket);
                    //$scope.NotificationSocket(ticket);
                     $scope.data.push(ticket);
                });
                
                
//                $scope.loadTatExceededTickets = function (tickets) {
//                    if (tickets) {
//                        // console.log(tickets) 
//                        angular.forEach(tickets, function (value, key) {
//                            //console.log(value);
//                            console.log(value.status);
//                            
//                            //this.push(key + ': ' + value);
//                        });
//                    }
//                }


//                $scope.loadChangesTable = function () {
//                    var url = "/api/dashboard/changes";
//                    $scope.changes = {};
//                    httpService.callRestApi(null, url, "GET")
//                            .then(function (response) {
//                                $scope.changes = response.data;
//                            }, function (reason) {
//                                $location.path('/oops/');
//                            });
//                }
//
//                $scope.loadRfiTable = function () {
//                    var url = "/api/dashboard/requests";
//                    $scope.rfi = {};
//                    httpService.callRestApi(null, url, "GET")
//                            .then(function (response) {
//                                $scope.rfi = response.data;
//                            }, function (reason) {
//                                $location.path('/oops/');
//                            });
//                }
//
//                $scope.populateIncidentTile = function () {
//                    var url = "/api/dashboard/incidents-month";
//                    httpService.callRestApi(null, url, "GET")
//                            .then(function (response) {
//                                $scope.incidentCount = response.data.length;
//                            }, function (reason) {
//
//                            });
//                }
//                $scope.populateChangeTile = function () {
//                    var url = "/api/dashboard/changes-month";
//                    httpService.callRestApi(null, url, "GET")
//                            .then(function (response) {
//                                $scope.changeCount = response.data.length;
//                            }, function (reason) {
//                            });
//                }
            }])
        .factory('Ticket', ['$http', function ($http) {
                function Ticket(ticketData) {
                    if (ticketData) {
                        this.setData(ticketData);
                    }
                    // Some other initializations related to ticket
                }
                ;
                Ticket.prototype = {
                    setData: function (ticketData) {
                        //console.log('ticket data setData',ticketData);
                        angular.extend(this, ticketData);
                    }
//                    delete: function () {
//                        $http.delete('ourserver/tickets/' + ticketId);
//                    },
//                    update: function () {
//                        $http.put('ourserver/tickets/' + ticketId, this);
//                    },
//                    getImageUrl: function (width, height) {
//                        return 'our/image/service/' + this.ticket.id + '/width/height';
//                    },
//                    isAvailable: function () {
//                        if (!this.ticket.stores || this.ticket.stores.length === 0) {
//                            return false;
//                        }
//                        return this.ticket.stores.some(function (store) {
//                            return store.quantity > 0;
//                        });
//                    }
                };
                return Ticket;
            }])

        .factory('ticketsManager', ['$http', '$q', 'Ticket', function ($http, $q, Ticket) {
                var ticketsManager = {
                    _pool: {},
                    _retrieveInstance: function (ticketId, ticketData) {
                        //console.log('retrive Instence', ticketId);
                        var instance = this._pool[ticketId];
                        if (instance) {
                            instance.setData(ticketData);
                        } else {
                            instance = new Ticket(ticketData);
                            //console.log('instence', instance);
                            this._pool[ticketId] = instance;
                        }
                        return instance;
                    },
                    _search: function (ticketId) {
                        //console.log('tickets retrived ticket ID',ticketId);
                        //console.log(this._pool);
                        return this._pool[ticketId];
                    },
                    _load: function (ticketId, deferred) {
                        console.log('retrive data is called', ticketId);
                        var scope = this;
                        $http.get('/api/ticketsRelated/ticket-detail', {params: {ticketID: ticketId}}).success(function (ticketData) {
                            deferred.resolve(ticketData[0]);
                        }).error(function () {
                            deferred.reject();
                        });
                    },
                    /* Public Methods */
                    /* Use this function in order to get a ticket instance by it's id */
                    getTicket: function (ticketId) {
                        var deferred = $q.defer();
                        var ticket = this._search(ticketId);
                        //console.log(ticket);
                        if (ticket) {
                            //console.log('Ticket found', ticket);
                            deferred.resolve(ticket);
                        } else {
                            this._load(ticketId, deferred);
                            //console.log(this._load(ticketId, deferred));
                        }
                        return deferred.promise;
                    },
                    /* Use this function in order to get instances of all the tickets */
                    loadAllTickets: function () {
                        var deferred = $q.defer();
                        var scope = this;
                        $http.get('/api/ticketsRelated/ticket').success(function (ticketsArray) {
                            var tickets = [];
                            ticketsArray.forEach(function (ticeketData) {
                                var ticket = scope._retrieveInstance(ticeketData.ticketID, ticeketData);
                                //console.log(ticket);
                                tickets.push(ticket);
                            });
                            deferred.resolve(ticketsArray);
                        }).error(function () {
                            deferred.reject();
                        });
                        return deferred.promise;
                    },
                    loadMytickets: function () {

                    },
                    /*  This function is useful when we got somehow the ticket data and we wish to store it or update the pool and get a ticket instance in return */
                    setTicket: function (ticketData) {
                        var scope = this;
                        var ticket = this._search(ticketData.id);
                        if (ticket) {
                            ticket.setData(ticketData);
                        } else {
                            ticket = scope._retrieveInstance(ticketData);
                        }
                        return ticket;
                    }
                };
                return ticketsManager;
            }])


//                $scope.loadTickets = function () {
//                    console.log('called');
//                     ticketsManager.loadAllTickets().then(function(tickets){
//                         $scope.data = tickets;
//                         //console.log($scope.data);
//                         
//                     },function(error){
//                         console.log(error);
//                     })
////                    var url = "/api/dashboard/incidents";
////                    $scope.data = {};
////                    httpService.callRestApi(null, url, "GET")
////                            .then(function (response) {
////                                $scope.data = response.data;
////                            }, function (reason) {
////                                $location.path('/oops/');
////                            });
//                }

//                    var url = "/api/dashboard/incidents";
//                    $scope.data = {};
//                    httpService.callRestApi(null, url, "GET")
//                            .then(function (response) {
//                                $scope.data = response.data;
//                            }, function (reason) {
//                                $location.path('/oops/');
//                            });

//                    $scope.loadChangesTable();
//                    $scope.loadRfiTable();
//                    $scope.populateChangeTile();
//                    $scope.populateIncidentTile();