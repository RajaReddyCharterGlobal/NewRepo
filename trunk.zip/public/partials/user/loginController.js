/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular.module('helpDesk')
        .controller('loginAppCtrl', ['$scope', '$window', 'httpService', 'AuthService', '$state',
            function ($scope, $window, httpService, AuthService, $state) {
                //console.log('login controller loaded');
                //$state.go('dashboard.main');
                $scope.loginSubmit = function (cred) {
                    $scope.loginProgress = true;
                    AuthService.login(cred).then(function (msg) {
                        $scope.loginProgress = true;
                        $state.go('dashboard.main');
                    }, function (errMsg) {
                        console.log(errMsg);
                        $scope.errorMsg = errMsg;
                        $scope.loginProgress = false;
                        $("#danger-alert").show();
                    });

                }
                //console.log($window);

                $scope.forgetpwdSubmit = function (email) {
                    //console.log('email received', email);
                    $scope.loginProgress = true;
                    AuthService.resetPwd(email).then(function (msg) {
                        $scope.loginProgress = false;
                        $scope.successMsg = msg;
                        $scope.frgtpwd.email = '';
                        $("#danger-alert").hide();
                        $("#success-alert").show();
                        //console.log('success msg',msg);
                    }).catch(function (e) {
                        $scope.errorMsg = e;
                        $scope.loginProgress = false;
                        $("#danger-alert").show();
                        //console.log('error occured',e); // "oh, no!"
                    })
                }

            }]);