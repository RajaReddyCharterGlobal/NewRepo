/**
 * Created by Pkp on 5/10/2016.
 */
angular.module('helpDesk')
        .controller('teamCtrl', ['$scope', '$window', 'httpService', '$stateParams', '$filter', '$location',
            function ($scope, $window, httpService, $stateParams, $filter, $location) {
                $scope.udata = {};
                $scope.addMember = function (memberDetails) {
                    //console.log(memberDetails);
                    if (memberDetails.mNum.toString().length !== 10) {
                        $scope.errorMsg = 'Please Enter valid 10 digit mobile number';
                        $("#danger-alert").show();
                    } else {
                        //console.log(memberDetails.aNum)
                        $scope.submitButtonClass = true;
                        $scope.resetButtonClass = true;
                        var url = "/api/team/add-member";
                        $("#loader").show();
                        httpService.callRestApi(memberDetails, url, "POST")
                                .then(function (response) {
                                    console.log(response.data);
                                    $scope.membermailid = response.data;
                                    $("#loader").hide();
                                    //$scope.incidentID = response.data.incidentID;
                                    $("#success-alert").show();
                                    $("#danger-alert").hide();
                                    $scope.createNewButtonClass = true;
                                }, function (reason) {
                                    $("#loader").hide();
                                    $scope.errorMsg = reason.msg;
                                    $("#danger-alert").show();
                                    console.log(reason);
                                    //$scope.createNewButtonClass = true;
                                    $scope.submitButtonClass = false;
                                });
                    }

                    //} else {
                    //  alert("Please fill out all fields");
                    //}
                }

                $scope.resetForm = function () {
                    $window.location.reload();
                }

                $scope.newMember = function () {
                    $window.location.reload();
                }


                $scope.getMemberDetail = function () {
                    //console.log('get detail Loaded');
                    $scope.isVisible = false;
                    //console.log($stateParams);
                    $scope.memberID = $stateParams.memberID;
                    //console.log($scope.incId);
                    $("#loader").show();
                    findIncidentById($scope.memberID);
                }

                $scope.updateProfile = function (data) {
                    if (data.npwd && (data.npwd === data.renterpwd && data.email)) {
                        $("#loader").show();
                        var udata = {
                            npwd: data.npwd,
                            email: data.email
                        };
                        var url = "/api/user/update-password";
                        httpService.callRestApi(udata, url, "POST")
                                .then(function (response) {
                                    console.log(response);
                                    $("#success-alert").show();
                                    $("#danger-alert").hide();
                                    $("#loader").hide();
                                    $scope.data.npwd = '';
                                    $scope.data.renterpwd = '';
                                    $scope.isClosed = true;
                                }, function (reason) {
                                    $scope.errorMsg = reason;
                                    $("#danger-alert").show();
                                    $("#loader").hide();
                                    $scope.isClosed = false;
                                });
                    }

                    if ($scope.OldAccessRole !== data.accessRole) {
                        $("#loader").show();
                        var udata = {
                            email: data.email,
                            accessRole: data.accessRole
                        };
                        var url = "/api/team/update-memberinfo";
                        httpService.callRestApi(udata, url, "POST")
                                .then(function (response) {
                                    //console.log(response);
                                    $("#danger-alert").hide();
                                    $("#success-alert").show();
                                    $("#loader").hide();
                                    $scope.isClosed = true;
                                }, function (reason) {
                                    $scope.errorMsg = reason;
                                    $("#danger-alert").show();
                                    $("#loader").hide();
                                    $scope.isClosed = false;
                                });
                    }
                    if (!data.npwd && $scope.OldAccessRole == data.accessRole) {
                        $("#danger-alert").show();
                        $("#loader").hide();
                        $scope.errorMsg = 'Nothing changed to update!';
                        $scope.isClosed = false;
                    }
                }

                $scope.updateIncident = function (data) {
                    $("#loader").show();
                    $scope.newData = {};
                    $scope.newData.incidentID = data.incidentID;
                    $scope.newData.application = data.application;
                    $scope.newData.incidentType = data.incidentType;
                    $scope.newData.priority = data.priority;
                    $scope.newData.releaseDate = data.releaseDate;
                    $scope.newData.resolutionType = data.resolutionType;
                    $scope.newData.site = data.site;
                    $scope.newData.status = data.status;
                    $scope.newData.title = data.title;
                    $scope.newData.version = data.version;
                    $scope.newData.description = addUpdate(data.update, data.description);

                    var url = "/api/incident/update";

                    httpService.callRestApi($scope.newData, url, "POST")
                            .then(function (response) {
                                findIncidentById(response.data.incidentID);
                                $("#success-alert").show();
                            }, function (reason) {
                                $("#loader").hide();
                                $scope.errorMsg = reason;
                                $("#danger-alert").show();
                            });
                }

                var addUpdate = function (update, desc) {
                    var date = new Date();
                    var updateDT = (date.getMonth() + 1).toString() + "/" + date.getDate().toString() + "/" + date.getFullYear().toString() + "  " + date.getHours().toString() + ":" + date.getMinutes().toString();
                    var updateString = "------ Status : " + $scope.newData.status + " | Last Updated by user at " + updateDT + " ------" + "\n";
                    desc = desc + "\n" + updateString + update;
                    return desc;
                }

                var findIncidentById = function (memID) {
                    var url = "/api/team/member-detail";
                    $scope.data = {};
                    httpService.callRestApi({memberID: memID}, url, "POST")
                            .then(function (response) {
                                //console.log(response.data);
                                $("#loader").hide();
                                if (response.data._id != undefined) {
                                    $scope.isVisible = true;
                                    console.log($scope.data);
                                    $scope.data = response.data;
                                    $scope.OldAccessRole = $scope.data.accessRole;
                                    //console.log($scope.OldAccessRole);
                                } else {
                                    $("#loader").hide();
                                    //$location.path('/damn-it/');
                                }
                            }, function (reason) {
                                $("#loader").hide();
                                $location.path('/oops/');
                            });
                }


                $scope.loadMembersTable = function () {
                    $("#loader").show();
                    var url = "/api/team/members";
                    $scope.data = {};
                    httpService.callRestApi(null, url, "GET")
                            .then(function (response) {
                                //console.log($scope.data);
                                $("#loader").hide();
                                $scope.data = response.data;
                            }, function (reason) {
                                $("#loader").hide();
                                $location.path('/oops/');
                            });
                }

                //$scope.phoneNumbr = /^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/;
            }]);


//console.log('$scope.data assigned as ', $scope.data);
//$scope.data.reportedDate = $filter("date")(response.data.reportedDate, 'MM/dd/yyyy HH:mm:ss');
//$scope.data.releaseDate = $filter("date")(response.data.releaseDate, 'yyyy-MM-dd');
//console.log('AAAAA-' + response.data.accessRole);
//                                    if (response.data.accessRole == "member")
//                                    {
//                                        $("#roleDiv").disable;
//                                        console.log('BBBBBB-' + response.data.accessRole);
//                                    } else {
//                                        // $("#roleDiv").enable();
//                                    }


//                $scope.updatePwd = function (data) {
//                    //console.log(data.npwd);
//                    $("#loader").show();
//                    if (data.npwd && (data.npwd !== data.renterpwd || !data.email)) {
//                        $scope.errorMsg = 'Password did not match & email is not valid';
//                        $("#danger-alert").show();
//                        $("#loader").hide();
//                    } else {
//
//                        if ($scope.OldAccessRole !== data.accessRole) {
//                            var udata = {
//                                npwd: data.npwd,
//                                email: data.email,
//                                accessRole: data.accessRole
//                            };
//                        } else {
//                            var udata = {
//                                npwd: data.npwd,
//                                email: data.email
//                            };
//                        }
//                        console.log(udata);
//
//                        console.log('update AccessRole : ' + data.accessRole);
//
//                        var url = "/api/user/update-password";
//                        httpService.callRestApi(udata, url, "POST")
//                                .then(function (response) {
//                                    console.log(response);
//                                    $("#success-alert").show();
//                                    $("#loader").hide();
//                                    if (data.data.npwd) {
//                                        $scope.data.data.npwd = '';
//                                        $scope.data.data.renterpwd = '';
//                                    }
//                                    $scope.isClosed = true;
//                                }, function (reason) {
//                                    $("#loader").hide();
//                                    $scope.errorMsg = reason;
//                                    $("#danger-alert").show();
//                                    $("#loader").hide();
//                                    $scope.isClosed = false;
//                                });
//                    }
//
//                }