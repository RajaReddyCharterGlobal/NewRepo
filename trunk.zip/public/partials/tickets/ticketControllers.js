angular.module('helpDesk')
        .controller('ticketCtrl', ['$scope', '$window', 'httpService', '$stateParams', '$filter', '$location', '$sce', '$rootScope', '$timeout', 'DTOptionsBuilder',
            function ($scope, $window, httpService, $stateParams, $filter, $location, $sce, $rootScope, $timeout, DTOptionsBuilder) {
                $scope.commentsList = {};
                $scope.getTicketDetail = function () {
                    //console.log('getIncidentDetail triggered');
                    $scope.isVisible = false;
                    $scope.ticeketID = $stateParams.ticketID;
                    $("#loader").show();
                    console.log($scope.ticeketID);
                    if ($scope.ticeketID) {
                        findTicketById($scope.ticeketID);
                        $scope.loadTicketComments($scope.ticeketID);
                        $scope.loadMembersTable();
                    }

                }
                $scope.tracktime = function (data, status) {
                    //console.log(data, "data from ");
                    //console.log(status, "status value");
                    //$scope.status=
                    var url = "/api/ticketsRelated/ticket-time-tracker";
                    if (status) {
                        var params = {
                            ticketID: $scope.data.ticketID,
                            service_type: 0
                        }
                        //console.log(params);
                        httpService.callRestApi(params, url, "POST").then(function (response) {
                            $("#loader").hide();
                        }, function (reason) {
                            $("#loader").hide();
                            $location.path("/oops/");
                        });
                    } else {
                        var params = {
                            ticketID: $scope.data.ticketID,
                            service_type: 1
                        }
                        //console.log(params);
                        httpService.callRestApi(params, url, "POST").then(function (response) {
                            $("#loader").hide();
                        }, function (reason) {
                            $("#loader").hide();
                            $location.path("/oops/");
                        });

                    }
                    ;
                }
                $scope.loadTicketsTable = function () {
                    $("#loader").show();
                    var url = "/api/ticketsRelated/ticket";
                    $scope.ticketsList = {};
//                    socketio.on('ticket', function (ticket) {
//                        console.log(ticket, 'realtime message');
//                        $scope.NotificationSocket(ticket);
//                        $scope.ticketsList.push(ticket);
//                    });
                    httpService.callRestApi(null, url, "GET").then(function (response) {
                        $("#loader").hide();
                        $scope.ticketsList = response.data;
                        for (var i = 0; i < response.data.length; i++) {
                            $scope.ticketsList[i].spent_hrs = $scope.getHrsSpent(response.data, i);
                        }
                        ;
                        //console.log($scope.ticketsList, 'after for loop');
                    }, function (reason) {
                        $("#loader").hide();
                        $location.path("/oops/");
                    });
                };
                //console.log($scope.membersList);
                $scope.loadMembersTable = function () {
                    $("#loader").show();
                    var url = "/api/team/members";
                    $scope.membersList = {};
                    httpService.callRestApi(null, url, "GET")
                            .then(function (response) {
                                //console.log($scope.data);
                                $("#loader").hide();
                                $scope.membersList = response.data;
                                console.log($scope.membersList, 'membersList after');
                            }, function (reason) {
                                $("#loader").hide();
                                $location.path('/oops/');
                            });
                }
                $scope.getHrsSpent = function (data, i) {
                    //console.log(data,'from spentFunction');
                    if (data[i].hrs_spent_start > 0) {
                        var seconds = Math.floor((Date.now() - (data[i].hrs_spent_start)) / 1000);
                        var minutes = Math.floor(seconds / 60);
                        var hours = Math.floor(minutes / 60);
                        var days = Math.floor(hours / 24);
                        hours = hours - (days * 24);
                        minutes = minutes - (days * 24 * 60) - (hours * 60);
                        seconds = seconds - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);
                        //console.log(hours + "hr" + minutes +"min"+ seconds+"sec",'time log');
                        $scope.hours_spent = hours + "hr" + " " + minutes + "min" + " " + seconds + "sec";
                        return $scope.hours_spent;
                    } else {
                        $scope.hours_spent = "0 hrs";
                        return $scope.hours_spent;
                    }
                }
                $scope.ticketHrsTracking = function (data) {
                    var url = "/api/ticketsRelated/ticket-time-tracker";
                    httpService.callRestApi(data.ticketID, url, "POST")
                            .then(function (response) {
                                $("#success-alert").show();
                            }, function (reason) {
                                $("#loader").hide();
                                $scope.errorMsg = reason;
                                $("#danger-alert").show();
                            });
                };
                /* $scope.updateTicket = function (data) {
                 console.log('updateTicket has been called', data);
                 $("#loader").show();
                 $scope.newData = {};
                 $scope.newData.ticketID = data.ticketID;
                 $scope.newData.tat_time = data.tat_time;
                 $scope.newData.assign_to = data.assign_to;
                 $scope.newData.status = data.status;
                 $scope.newData.priority = data.version;
                 var url = "/api/ticketsRelated/ticket-detail";
                 httpService.callRestApi($scope.newData, url, "POST")
                 .then(function (response) {
                 $("#loader").hide();
                 $("#success-alert").show();
                 }, function (reason) {
                 $("#loader").hide();
                 $scope.errorMsg = reason;
                 $("#danger-alert").show();
                 });
                 }*/
                $scope.loadTicketComments = function (ticket_ID) {
                    $("#loader").show();
                    var url = "/api/ticketsRelated/comment";
                    var params = {
                        tid: ticket_ID
                    }
                    httpService.callRestApi(params, url, "GET").then(function (response) {
                        $("#loader").hide();
                        $scope.commentsList = response.data;
                    }, function (reason) {
                        $("#loader").hide();
                        $location.path("/oops/");
                    });
                };
                var findTicketById = function (ticID) {
                    var url = "/api/ticketsRelated/ticket-detail";
                    $scope.data = {};
                    httpService.callRestApi({
                        ticketID: ticID
                    }, url, "GET").then(function (response) {
                        $("#loader").hide();
                        if (response.data[0].ticketID != undefined) {

                            $scope.isVisible = true;
                            $scope.data = response.data[0];

                            console.log("status", response.data[0].status);

                            if (response.data[0].status == "New")
                            {
                                updateTicketOwnership(response.data[0]._id);
                                //console.log('after updateTicketOwnership ......');
                            }


                            if ($scope.data.assign_to != undefined) {
                                $scope.data.assign_to = $scope.data.assign_to._id;
                            }
                            $scope.data.reportedDate = $filter("date")(response.data[0].reportedDate, 'MM/dd/yyyy HH:mm:ss');
//                            $scope.formatedHTML = function (descriptionData) {
//                                return $sce.trustAsHtml(descriptionData);
//                            };
                        } else {
                            $("#loader").hide();
                        }
                    }, function (reason) {
                        $("#loader").hide();
                        $location.path('/oops/');
                    });
                }
                $scope.formatedHTML = function (descriptionData) {
                    return $sce.trustAsHtml(descriptionData);
                };
                var updateTicketOwnership = function (recID) {

                    console.log("updateTicketOwnership ............");
                    var url = "/api/ticketsRelated/ticket-Ownership";
                    //  $scope.data = {};
                    var actmsg = $rootScope.userObj.fName + " " + $rootScope.userObj.lName + " has ownership for this ticket on " + $filter('date')(new Date(), 'yyyy-MM-dd HH:mm:ss');
                    httpService.callRestApi({
                        recID: recID, ownerid: $rootScope.userObj._id, msg: actmsg
                    }, url, "POST").then(function (response) {
                        console.log(response.status);

                        if (response.status == 200) {
                            console.log("Status updated ...", response);

                            $scope.data.ownerid = $rootScope.userObj;
                            $scope.data.activityLogs.push(actmsg);

                        }
                    });
                }

                $scope.addComment = function (data) {
                    $("#loader").show();
                    var cmodel = {
                        ticketID: $scope.data.ticketID,
                        tid: $scope.data._id,
                        reportedby: $scope.data.empName,
                        reportedbyemail: $scope.data.empEmail,
                        comment: data.comment,
                        userid: $rootScope.userObj._id,
                        username: $rootScope.userObj.fName + $rootScope.userObj.lName,
                        notify: false
                    };

                    var url = "/api/ticketsRelated/add-comment";
                    httpService.callRestApi(cmodel, url, "POST")
                            .then(function (response) {
                                $("#loader").hide();
                                $scope.commentData.comment = '';
                                $scope.commentData.notify = null;
                                var totalComments = $scope.commentsList.length;
                                $scope.commentsList[totalComments] = response.data;
                            }, function (reason) {
                                $("#loader").hide();
                                $scope.errorMsg = reason;
                                $("#danger-alert").show();
                            });
                }

                $scope.sendCommentToEmp = function (empComment) {
                    $("#loader").show();
                    var cmodel = {
                        ticketID: $scope.data.ticketID,
                        //tid: $scope.data._id,
                        reportedby: $scope.data.empName,
                        reportedbyemail: $scope.data.empEmail,
                        comment: empComment.comment,
                        userid: $rootScope.userObj._id,
                        username: $rootScope.userObj.fName + $rootScope.userObj.lName,
                        notifyEmp:true
                    };

                    var url = "/api/ticketsRelated/add-comment-emp";
                    console.log('data passed between data',cmodel);
                    httpService.callRestApi(cmodel, url, "POST")
                            .then(function (response) {
                                $("#loader").hide();
                                //console.log(response);
                                $scope.empComment.comment = '';
                                //$scope.commentData.notify = null;
                                var totalComments = $scope.commentsList.length;
                                $scope.commentsList[totalComments] = response.data;
                            }, function (reason) {
                                $("#loader").hide();
                                $scope.errorMsg = reason;
                                $("#danger-alert").show();
                            });
                }
                $scope.focusCallback = function ($event) {
                    $scope.attributeName = $event.target.id;
                }
                $scope.updateActivityAndTicket = function (prameter, fromVal, toVal) {
                    //var logText = "  " + $scope.changedByName + " has changed " + $scope.attributeName + "  from  " + $scope.attributeFromVal + " to " + $scope.attributeToVal + " on " + $scope.FromDate
                    //$scope.newData.activityLogs = "  " + $scope.changedByName + " has changed " + $scope.attributeName + "  from  " + $scope.attributeFromVal + " to " + $scope.attributeToVal + " on " + $scope.FromDate;
                    //console.log('data receoved', prameter, fromVal, toVal);
                    $scope.FromDate = $filter('date')(new Date(), 'yyyy-MM-dd HH:mm:ss');
                    var activityLogtitle = '';
                    var logText, toValText, fromValText = '';
                    if (prameter == 'status') {
                        activityLogtitle = 'status';
                        //if(toVal=='Closed'){$scope.newData.closedDate = new Date();}
                    } else if (prameter == 'tat_time') {
                        activityLogtitle = 'Tat time';
                    } else if (prameter == 'priority') {
                        activityLogtitle = 'priority';
                    } else if (prameter == 'assign_to') {
                        activityLogtitle = 'assigned to';
                        angular.forEach($scope.membersList, function (value) {
                            if (value._id === toVal) {
                                toValText = value.fName + ' ' + value.lName;
                            }
                            if (fromVal && value._id === fromVal) {
                                fromValText = value.fName + ' ' + value.lName;
                            }
                        });
                    } else if (prameter == 'issue_type_cat_1' || prameter == 'issue_type_cat_2' || prameter == 'issue_type_cat_3') {
                        activityLogtitle = 'category';
                    } else {
                        activityLogtitle = prameter;
                    }

                    var userName = $rootScope.userObj.fName + " " + $rootScope.userObj.lName;


                    if (prameter == 'assign_to') {
                        logText = "  " + userName + " has changed " + activityLogtitle + "  from  " + toValText + " to " + fromValText + " on " + $scope.FromDate;
                    } else {
                        logText = "  " + userName + " has changed " + activityLogtitle + "  from  " + fromVal + " to " + toVal + " on " + $scope.FromDate;
                    }
                    var values = {
                        parameter: prameter,
                        fromVal: fromVal,
                        toVal: toVal,
                        activityLog: logText,
                        ticketID: $scope.data.ticketID
                    }
                    var url = "/api/ticketsRelated/ticket-details-update";
                    httpService.callRestApi(values, url, "POST")
                            .then(function (response) {
                                if (response) {
                                    console.log(response);
                                    $scope.data[prameter] = toVal;
                                    $scope.data.activityLogs.push(logText);
                                }
                            }, function (reason) {
                                console.log(reason);
                                $scope.errorMsg = reason;
                                console.log($scope.errorMsg, "error message");
                            });
                }


                $scope.issueTypeCat1 = {
                    'hardware': {
                        'request': {
                            'System Configuration Upgrade': 'System Configuration Upgrade',
                            'New Hardware Component': 'New Hardware Component',
                            'New System': 'New System',
                            'New Server Setup': 'New Server Setup',
                        },
                        'issue': {
                            'Mouse Not working': 'Mouse Not Working',
                            'Keyboard Not working': 'Keyboard Not working',
                        }
                    },
                    'software': {
                        'request': {
                            'New Software Installation': 'New Software Installation',
                            'Update Software': 'Update Sofware',
                            'Purchase New Sofware': 'Purchase New Sofware',
                            'Sofware Licence': 'Sofware Licence',
                        },
                        'issue': {
                            'Licence Expired': 'Licence Expired',
                            'Software compatibility': 'Software compatibility',
                        }
                    },
                    'Network': {
                        'request': {
                            'Youtube Access': 'Youtube Access',
                            'Website Access': 'Website Access',
                            'Wifi Access': 'Wifi Access',
                        },
                        'issue': {
                            'Issue in accesing Wifi': 'Issue in accesing Wifi',
                            'Issue in accessing LAN network': 'Issue in accessing LAN network',
                        }
                    }
                }
                $scope.issueTypeCat2 = {
                    'request': {
                        'hardware': {
                            'System Configuration Upgrade': 'System Configuration Upgrade',
                            'New Hardware Component': 'New Hardware Component',
                            'New System': 'New System',
                            'New Server Setup': 'New Server Setup',
                        },
                        'software': {
                            'New Software Installation': 'New Software Installation',
                            'Update Software': 'Update Sofware',
                            'Purchase New Sofware': 'Purchase New Sofware',
                            'Sofware Licence': 'Sofware Licence',
                        },
                        'Network': {
                            'Youtube Access': 'Youtube Access',
                            'Website Access': 'Website Access',
                            'Wifi Access': 'Wifi Access',
                        }
                    },
                    'issue': {
                        'hardware': {
                            'Mouse Not working': 'Mouse Not Working',
                            'Keyboard Not working': 'Keyboard Not working',
                        },
                        'software': {
                            'Licence Expired': 'Licence Expired',
                            'Software compatibility': 'Software compatibility',
                        },
                        'Network': {
                            'Issue in accesing Wifi': 'Issue in accesing Wifi',
                            'Issue in accessing LAN network': 'Issue in accessing LAN network',
                        }
                    }
                }

                $scope.issueTypeCat3 = {
                    '0': {key: 'request',
                        value: {
                            'hardware': {
                                'System Configuration Upgrade': 'System Configuration Upgrade',
                                'New Hardware Component': 'New Hardware Component',
                                'New System': 'New System',
                                'New Server Setup': 'New Server Setup',
                            },
                            'software': {
                                'New Software Installation': 'New Software Installation',
                                'Update Software': 'Update Sofware',
                                'Purchase New Sofware': 'Purchase New Sofware',
                                'Sofware Licence': 'Sofware Licence',
                            },
                            'Network': {
                                'Youtube Access': 'Youtube Access',
                                'Website Access': 'Website Access',
                                'Wifi Access': 'Wifi Access',
                            }
                        }},
                    '1': {key: 'issue', values: {
                        }},
                    'issue': {
                        'hardware': {
                            'Mouse Not working': 'Mouse Not Working',
                            'Keyboard Not working': 'Keyboard Not working',
                        },
                        'software': {
                            'Licence Expired': 'Licence Expired',
                            'Software compatibility': 'Software compatibility',
                        },
                        'Network': {
                            'Issue in accesing Wifi': 'Issue in accesing Wifi',
                            'Issue in accessing LAN network': 'Issue in accessing LAN network',
                        }
                    }
                }
                $scope.dtOptions = DTOptionsBuilder.newOptions().withOption('order', [[0, 'desc']]);

                $scope.$on('NewTicket', function (event, ticket) {
                    console.log('realtime message', ticket);
                    //$scope.NotificationSocket(ticket);
                    $scope.ticketsList.push(ticket);
                });

            }])

        .directive('bootstrapSwitch', [
            function () {
                return {
                    restrict: 'A',
                    require: '?ngModel',
                    link: function (scope, element, attrs, ngModel) {
                        element.bootstrapSwitch();

                        element.on('switchChange.bootstrapSwitch', function (event, state) {
                            if (ngModel) {
                                scope.$apply(function () {
                                    ngModel.$setViewValue(state);
                                });
                            }
                        });

                        scope.$watch(attrs.ngModel, function (newValue, oldValue) {
                            if (newValue) {
                                element.bootstrapSwitch('state', true, true);
                            } else {
                                element.bootstrapSwitch('state', false, true);
                            }
                        });
                    }
                };
            }
        ])
        .directive('ngHtml', ['$compile', function ($compile) {
                return function (scope, elem, attrs) {
                    if (attrs.ngHtml) {
                        elem.html(scope.$eval(attrs.ngHtml));
                        $compile(elem.contents())(scope);
                    }
                    scope.$watch(attrs.ngHtml, function (newValue, oldValue) {
                        if (newValue && newValue !== oldValue) {
                            elem.html(newValue);
                            $compile(elem.contents())(scope);
                        }
                    });
                };
            }]);
// $scope.newData.application = data.application;
// $scope.newData.incidentType = data.incidentType;
// $scope.newData.priority = data.priority;
// $scope.newData.releaseDate = data.releaseDate;
// $scope.newData.resolutionType = data.resolutionType;

//                $scope.NotificationSocket = function (ticket) {
//                    var protocol = $location.protocol();
//                    var host = $location.host();
//                    var port = $location.port();
//                    if (!Notification) {
//                        alert('Desktop notifications not available in your browser. Try Chromium.');
//                        return;
//                    }
//                    console.log(Notification.permission, "permission");
//                    if (Notification.permission !== "granted")
//                        Notification.requestPermission();
//                    else {
//                        console.log('$scope.NotifictaionCustom is called');
//                        console.log('Notifictaion is called');
//                        var notification = new Notification(ticket.title, {
//                            icon: 'https://s3-us-west-2.amazonaws.com/it-helpdesk-cgi/clogo.PNG',
//                            body: 'New ticket raised by' + ' ' + ticket.empName,
//                        });
//                        var urlString = protocol + "://" + host + ":" + port + "/dashboard/tickets/ticket-detail/" + ticket.ticketID;
//                        notification.onclick = function () {
//                            window.open(urlString);
//                        };
//                    }
//                }

//console.log(response);
//                                $scope.data = response.data[0];
//                                if ($scope.data.assign_to) {
//                                    $scope.data.assign_to = $scope.data.assign_to._id;
//                                }


//                $scope.updateActivityAndTicket = function (toVal, fromVal) {
//                    $scope.newData = {};
//                    $scope.newData.ticketID = $scope.data.ticketID;
//                    $scope.newData.tat_time = $scope.data.tat_time;
//                    $scope.newData.status = $scope.data.status;
//                    $scope.newData.priority = $scope.data.priority;
//                    $scope.newData.issue_type_cat_1 = $scope.data.issue_type_cat_1;
//                    $scope.newData.issue_type_cat_2 = $scope.data.issue_type_cat_2;
//                    $scope.newData.issue_type_cat_3 = $scope.data.issue_type_cat_3;
//
//                    if ($scope.data.status === 'Closed') {
//                        $scope.newData.closedDate = new Date();
//                    }
//
//                    if ($scope.attributeName == 'assign_to') {
//                        angular.forEach($scope.membersList, function (value) {
//                            if (value._id === toVal) {
//                                $scope.attributeToVal = value.fName + ' ' + value.lName;
//                            }
//                            if (fromVal && value._id === fromVal) {
//                                $scope.attributeFromVal = value.fName + ' ' + value.lName;
//                            }
//
//                        });
//                    } else {
//                        $scope.attributeFromVal = fromVal;
//                        $scope.attributeToVal = toVal;
//                    }
//                    if ($scope.data.assign_to != undefined) {
//                        $scope.newData.assign_to = $scope.data.assign_to;
//                    }
//
//                    $scope.changedByName = $rootScope.userObj.fName + " " + $rootScope.userObj.lName;
//
//                    if ($scope.data.tat_time != null) {
//                        $scope.newData.tat_time = $scope.data.tat_time;
//                    } else {
//                        $scope.newData.tat_time = 0;
//                    }
//                    $scope.FromDate = $filter('date')(new Date(), 'yyyy-MM-dd HH:mm:ss');
//
//                    if (fromVal == undefined) {
//
//                        $scope.attributeFromVal = "none";
//                    }
//                    $scope.newData.activityLogs = "  " + $scope.changedByName + " has changed " + $scope.attributeName + "  from  " + $scope.attributeFromVal + " to " + $scope.attributeToVal + " on " + $scope.FromDate;
//
//                    var url = "/api/ticketsRelated/ticket-detail";
//                    httpService.callRestApi($scope.newData, url, "POST")
//                            .then(function (response) {
//                                $scope.data = response.data[0];
//                                if ($scope.data.assign_to) {
//                                    $scope.data.assign_to = $scope.data.assign_to._id;
//                                }
//                            }, function (reason) {
//                                $scope.errorMsg = reason;
//                                console.log($scope.errorMsg, "error message");
//                            });
//                }

//                     if (prameter === 'assign_to') {
//                        
//                    } else {
//                        fromVal = fromVal;
//                        toVal = toVal;
//                    }
//                $scope.updateTicketField = function (key, value) {
//                    var url = "/api/ticketsRelated/ticket-field-update";
//                    var data={};
//                    data.ticketID=$scope.data.ticketID;
//                    data.key=key;
//                    data.value=value;
//                    httpService.callRestApi(data, url, "POST")
//                            .then(function (response) {
//                                console.log(response);
////                                $scope.data = response.data[0];
////                                if ($scope.attributeName == 'assign_to') {
////                                    $scope.data.assign_to = $scope.data.assign_to._id;
////                                }
//                            }, function (reason) {
//                                $scope.errorMsg = reason;
//                            });
//                }