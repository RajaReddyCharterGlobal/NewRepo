/**
 * Created by Pkp on 5/14/2016.
 */

var express = require('express');
var router = express.Router();
var teamController = require('../controllers/team');
var passport = require('passport');
router.use(function (req, res, next) {
    next();
});

router.post('/add-member', passport.authenticate('jwt', {session: false}), function (req, res) {
    //var token = getToken(req.headers);
    //console.log(token);
    teamController.addMember(req, res);
});

router.get('/members',passport.authenticate('jwt', {session: false}), function (req, res) {
    teamController.membersList(res);
});

router.post('/member-detail',passport.authenticate('jwt', {session: false}), function (req, res) {
    console.log('entered Member Detail Controller',req.body.memberID);
    teamController.getMemberById(req.body.memberID, res);
});

router.post('/update-memberinfo',passport.authenticate('jwt', {session: false}), function (req, res) {
    console.log('entered Member Detail Controller',req.body.memberID);
    teamController.updateMemberinfo(req.body, res);
});

router.post('/update',passport.authenticate('jwt', {session: false}), function (req, res) {
    teamController.updateIncident(req.body, res);
})

module.exports = router;
