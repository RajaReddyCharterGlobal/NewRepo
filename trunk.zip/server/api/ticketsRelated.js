var express = require('express');
var router = express.Router({strict: true});
var passport = require('passport');


var ticketsController = require('../controllers/ticketsRelated');

router.use(function (req, res, next) {
    next();
});

router.get('/ticket', passport.authenticate('jwt', {session: false}), function (req, res) {
    console.log('Hi i received cal');
    ticketsController.getTicket(req, res);
});

router.get('/ticket-detail', passport.authenticate('jwt', {session: false}), function (req, res) {
    console.log('ticket detail trigger');
    //console.log(req.query);
    ticketsController.getTicketById(req, res);
});

router.post('/ticket-details-update', passport.authenticate('jwt', {session: false}), function (req, res) {
    console.log('request received',req.body,req.params);
    ticketsController.ticketAttributeUpdateByTeam(req, res);
});

router.post('/ticket-time-tracker', passport.authenticate('jwt', {session: false}), function (req, res) {
    console.log(req.body);
    req.body.service_type == 0 ? ticketsController.ticketHrsTrackerON(req, res) : ticketsController.ticketHrsTrackerOFF(req, res);
});

//comment route
router.post('/add-comment', passport.authenticate('jwt', {session: false}), function (req, res) {
    // console.log('comment detail post trigger',req.body);

    ticketsController.commentAddedByTeam(req, res);
});

//comment route
router.post('/add-comment-emp', passport.authenticate('jwt', {session: false}), function (req, res) {
    // console.log('comment detail post trigger',req.body);
    ticketsController.commentAddedByTeamToEmp(req, res);
});

router.get('/comment', passport.authenticate('jwt', {session: false}), function (req, res) {

    ticketsController.getComments(req.query.tid, res);
});

router.post('/ticket-Ownership', passport.authenticate('jwt', {session: false}), function (req, res) {
    //console.log('ticket detail trigger....');
    ticketsController.ticketOwnerUpdate(req, res);
});
module.exports = router;

//router.post('/ticket-field-update', function (req, res) {
//
//    ticketsController.ticketFieldUpdate(req.body, res);
//});

//var mailistenerController = require('../controllers/maillistener.js');
//var ControllerConstruct = new mailistenerController({});