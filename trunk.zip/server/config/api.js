module.exports = function(app){
    app.use('/api/dashboard', require('../api/dashboard'));
    app.use('/api/team', require('../api/team'));
    app.use('/api/search', require('../api/search'));
    app.use('/api/user', require('../api/user'));
    //Tickets
    //app.use('/api/tickets', require('../api/tickets'));
    app.use('/api/ticketsRelated', require('../api/ticketsRelated'));
};