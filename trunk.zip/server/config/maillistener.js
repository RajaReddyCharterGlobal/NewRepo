// Maillistner 
var MailListener = require("../controllers/maillistener");
var ticketsController = require("../controllers/ticketsRelated");
//var mailListnerModel = require('../server/models/mailListnerModels');
//var mailListnerModels = require('mongoose').model('ticket');
var aws_s3 = require('../controllers/aws-s3');
var striptags = require('striptags');

module.exports = function (mailConfig) {
    //console.log(config);
    // console.log(mailConfig);
    //console.log(mailConfig);
    var mailListener = new MailListener(mailConfig);

    mailListener.start();

    mailListener.on("server:connected", function () {
        console.log("imapConnected");
    });

    mailListener.on("server:disconnected", function () {
        console.log("imapDisconnected");
    });

    mailListener.on("error", function (err) {
        console.log(err);
    });

    var tID = null;
    //var ticketID = Date.now();
    var generateTicketID = function () {
        return Date.now();
    };
    mailListener.on("attachment", function (attachment) {
        //console.log('attachements called first');
        if (!tID) {
            tID = generateTicketID();
            console.log('Attachment Ticket-ID NOT exist', tID);
        } else {
            console.log('Attachement Ticket-ID Exist', tID);
        }
        //console.log('Attachement Ticket-ID:', tID);
        //var ID = ticketID();
        //console.log('attachement name', attachment.fileName);
        aws_s3(attachment, tID);
    });
    mailListener.on("mail", function (mail) {
        //console.log('Mail Received and ticket ID',tID);
        //console.log('Attachement Ticket-ID:', tID);
        var emp_email = mail.from[0].address;
        var emp_name = mail.from[0].name;
        var subject = mail.subject;
        var description = mail.html;
        var cleanedHTMLTags = striptags(description);

        //var n = subject.match(/^#[0-9]*/);
        if(subject){
            var n = subject.match(/#[0-9]*/);
        }
        //console.log('some subject',n);
        if (n && n[0]) {
            //console.log('received a reply Mail');
            var ticketID = n[0].replace('#', '');
            var params = {
                ticketID: ticketID,
                emp_email: emp_email,
                emp_name: emp_name,
                subject: subject,
                comment: cleanedHTMLTags
            };
            if (tID) {
                //Attachments exist for comment reply mail
                params.attachTicketID=tID;
            }
            /*********************************************************
             *If Ticket Already exists add as a comment to the ticket
             *********************************************************/
            ticketsController.addCommentByEmployee(params);
            tID = null;
        } else {
            if (!tID) {
                tID = generateTicketID();
                console.log('Mail Ticket-ID NOT exist', tID);
            }
            ticketsController.createTicket(tID, emp_email, emp_name, subject, cleanedHTMLTags);
            tID = null;
        }

        //console.log('TID nullified');
    });

};

//var tID = ticketID();
//        striptags(html);
//        striptags(html, '<a><strong>');
//        striptags(html, ['a']);

