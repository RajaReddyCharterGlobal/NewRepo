var mongoose = require('mongoose');

var Member = mongoose.Schema(
        {
            email: {
                type: String,
                required: true,
                unique: true,
                lowercase: true
            },
            fName: {
                type: String,
                required: true,
                expose: false
            },
            lName: {
                type: String,
                required: true
            },
            mNum: {
                type: String,
                required: true
            },
            aNum: {
                type: String,
                required: false
            },
            empID: {
                type: String,
                required: true,
                unique: true,
                uppercase:true,
            },
            location: {
                type: String,
                required: true,
                uppercase:true,
            },
            designation: {
                type: String,
                required: true
            },
            accessRole: {
                type: String,
                required: true
            },
            created: {
                type: Date,
                default: Date.now
            }
        }
);
var Member = mongoose.model('Member', Member);
module.exports = Member;