/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var ticketsController = require("../controllers/ticketsRelated");

var params = {
    ticketID: 1472726079225,
    tID: 1324,
    reportedBy: "test User",
    reportedByEmail: 'test@gmail.com',
    comment: 'Some comment to test this case',
    //commentedByID: '',
    commentedByName: 'Test User'
}

ticketsController.addCommentByEmployee(params);