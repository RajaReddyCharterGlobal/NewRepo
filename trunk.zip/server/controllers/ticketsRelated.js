/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var ticketModel_parent = require('../models/tickets');
var ticketModel = require('mongoose').model('ticket');

var commentModel = require('../models/comment');
var commentModels = require('mongoose').model('comment');
var mailer = require('./mailer.js');
var request = require('request');

var App = require('./app.js');

var getTimeSpent = function (startTime, endTime) {
    var seconds = Math.floor((endTime - (startTime)) / 1000);
    var minutes = Math.floor(seconds / 60);
    var hours = Math.floor(minutes / 60);
    var days = Math.floor(hours / 24);
    hours = hours - (days * 24);
    minutes = minutes - (days * 24 * 60);
    //seconds = seconds-(days*24*60*60)-(hours*60*60)-(minutes*60);
    return minutes;
};

exports.createTicket = function (ticketID, email, name, subject, desc) {
    // console.log('create ticket method triggered');
    var mailListnerBody = {
        reportedBy_Mail: email,
        reportedBy_Name: name,
        title: subject,
        description: desc,
        ticketID: ticketID
    };
    //console.log('mailListnerBody create ticket called', mailListnerBody.ticketID);
    ticketModel.create({
        ticketID: mailListnerBody.ticketID,
        title: mailListnerBody.title,
        empEmail: mailListnerBody.reportedBy_Mail,
        empName: mailListnerBody.reportedBy_Name,
        description: mailListnerBody.description
    }, function (err, create) {
        if (err) {
            console.log(err);
        } else {
            console.log('create success with ID', create.ticketID);
//            var content = 'Thank you for contacting us.' +
//                    'This is an automated response confirming the receipt of your ticket.' +
//                    'Our team will get back to you as soon as possible.'
            var title = '#' + create.ticketID + ' ' + create.title;
            var params = {
                TicketID: create.ticketID
            }
            mailer.mailerService(create.empEmail, title, params, 'template-newticket');
            App.socketNotification(create);
        }
    }); /// Create Record Operation Ends here
};


exports.getTicket = function (req, res) {
    //console.log('getTicket triggered');
    ticketModel.find({}, function (err, details) {
        if (err) {
            console.log("error");
            return res.status(500).json("Internal Database error");
        }
        //res.status(200).json(details[0]);
        //console.log(details);
        res.send(details);
    }).sort({_id: -1}).populate('assign_to', '_id fName lName').exec(function (err, story) {
        if (err)
            //return handleError(err);
            return res.send(err);
    });
};

exports.getTicketById = function (req, res) {
    //console.log('getTicketById triggered with parameters', req.body);
    ticketModel.find({ticketID: req.query.ticketID}, function (err, found) {
        if (err) {
            res.status(500).json("Internal Database error");
            //res.send(err);
        } else {

            if (found.length <= 0) {
                res.send("Invalid Ticket Number!");
            } else {
                res.send(found);
            }
            ;
        }
        ;
    }).populate('assign_to ownerid').exec(function (err, story) {
        if (err)
            //return handleError(err);
            return res.send(err);
    });
};

exports.ticketHrsTrackerON = function (req, res) {
    //console.log('getTicketById triggered with parameters', req.body);
    ticketModel.find({ticketID: req.body.ticketID}, function (err, update) {
        if (err) {
            res.status(500).json("Internal Database error");
            //res.send(err);
        } else {

            if (update.length <= 0) {
                res.send("Invalid Ticket Number!");
            } else {
                var trackLogLength = update.time_track_log;
                //console.log(trackLogLength, 'trackLogLength');
                if (req.body.service_type == 0) {
                    var button_stat = true;
                }
                update[0].master_st == 0 ? ticketModel.findByIdAndUpdate({_id: update[0]._id},
                        {
                            $set: {
                                master_st: Date.now(),
                                track_button: button_stat
                            }
                        }, function (err, updated) {
                    if (err) {
                        res.send(err);
                    } else {
                        //res.status(200).json("Updated Record!!");
                        res.send(updated);
                    }
                    ;
                }) : ticketModel.findByIdAndUpdate({_id: update[0]._id},
                        {
                            $set: {
                                child_st: Date.now(),
                                track_button: button_stat
                            }
                        }, function (err, updated) {
                    if (err) {
                        res.send(err);
                    } else {
                        //res.status(200).json("Updated Record!!");
                        res.send(updated);
                    }
                    ;
                })
            }
            ;//else end
        }
        ;
    });
};

exports.ticketHrsTrackerOFF = function (req, res) {
    //console.log('came into off function');
    ticketModel.find({ticketID: req.body.ticketID}, function (err, update) {
        if (err) {
            res.status(500).json("Internal Database error");
            //res.send(err);
        } else {

            if (update.length <= 0) {
                res.send("Invalid Ticket Number!");
            } else {
                var startTime = (update[0].child_st == 0 ? update[0].master_st : update[0].child_st);
                var ext_hrs = update[0].total_hrs_spent;
                var button_stat = update[0].track_button;
                ticketModel.findByIdAndUpdate({_id: update[0]._id},
                        {
                            $set: {
                                halt_at: Date.now(),
                                total_hrs_spent: (ext_hrs + getTimeSpent(startTime, Date.now())),
                                track_button: !button_stat
                            }
                        }, function (err, updated) {
                    if (err) {
                        res.send(err);
                    } else {
                        //res.status(200).json("Updated Record!!");
                        res.send(updated);
                    }
                    ;
                });//Update op end
            }
            ;//else end
        }
        ;
    });
};
exports.ticketAttributeUpdateByTeam = function (req, res) {
    //console.log('received update request', req.body);
    var value = {};
    value[req.body.parameter] = req.body.toVal;
    if (req.body.parameter == 'status' && req.body.toVal == 'Closed') {
        var closedDate = new Date();
        value.closedDate = closedDate;
    }
    //console.log('value constructed', value);
    ticketModel.findOneAndUpdate({ticketID: req.body.ticketID},
            {
                $set: value,
                $push: {'activityLogs': req.body.activityLog}
            }, function (err, updated) {
        if (err) {
            console.log(err, 'error occured');
            res.status(500).send(err);
        } else {
            res.status(200).send('Success Updated value');
            //console.log('updated values', updated);
        }
    });
};

//var get_ticket_imageArray = function (ticketID) {
//    console.log(ticketID);
//    ticketModel.findOne({ticketID: ticketID}, function (err, ticket) {
//        if (!err) {
//            console.log(ticket);
////            ticketModel.findOneAndUpdate({ticketID: params.ticketID},
////                    {$set: {status: "Re-Open", img_Path: ticket.img_Path}},
////                    function (err, update) {
////                        if (err) {
////                            console.log(ticket)
////                        } else {
////                            //console.log('ticket got updated as',update._id)
////                            if (update && update._id) {
////                                var newCommentModel = new commentModel({
////                                    ticketID: params.ticketID,
////                                    tid: update._id,
////                                    reportedBy: params.emp_name,
////                                    reportedByEmail: params.emp_email,
////                                    comment: params.comment,
////                                    commentedByName: params.emp_name
////                                });
////                                newCommentModel.save(function (err, data) {
////                                    //console.log(err);
////                                    if (err) {
////                                        console.log('error occured while saving comment', err);
////                                        //return err;
////                                    } else {
////                                        console.log('New comment saved');
////                                        //return data;
////                                    }
////
////                                });
////                            }
////                        }
////                    });
//            return ticket;
//        } else {
//            return false;
//        }
//    });
//};

//get_ticket_imageArray('1474021302928')

//var add_




exports.commentAddedByTeam = function (req, res) {
    //console.log('comment detail - MailListener trigger',req.body);

    var commentBody = req.body;
    // console.log('comment detail - MailListener commentBody',commentBody);
    // console.log('comment detail - ticketID:',commentBody.ticketID);
    // console.log('comment detail...........', commentBody.reportedbyemail);
    var newCommentModel = new commentModel({
        ticketID: commentBody.ticketID,
        tid: commentBody.tid,
        reportedBy: commentBody.reportedby,
        reportedByEmail: commentBody.reportedbyemail,
        comment: commentBody.comment,
        commentedByID: commentBody.userid,
        commentedByName: commentBody.username,
        comment_type: 'team_team'
    });
    //console.log('comment detail - req ticketID:',req.body.ticketID);
    // console.log('comment detail - ticketID:',commentBody.ticketID);
    newCommentModel.save(function (err, data) {
        //console.log(err);
        if (err) {
            console.log('error occured while saving comment', err);
            res.status(400);
            return res.json({msg: 'comment is not able to save.'});
        } else {
            // console.log('comment saved success',commentBody);
            //if (commentBody.notify) {
            //var subject = '#' + commentBody.ticketID + ' - comment is added by ' + commentBody.username;
//                var content = commentBody.reportedby + "\n Comment: " + commentBody.comment
//                        + "\n\nRegards\n\n IT Team";
            //mailer.mailerService(req.body.email, 'Help Desk Reset Password', content);
            //mailer.mailerService(commentBody.reportedbyemail, subject, content);
            //}
            res.status(200);
            res.json(data);
        }

    });
};

exports.addCommentByEmployee = function (params) {
    //var ticketArray = null;
    var newCommentModel = new commentModel({
        ticketID: params.ticketID,
        //tid: update._id,
        reportedBy: params.emp_name,
        reportedByEmail: params.emp_email,
        comment: params.comment,
        commentedByName: params.emp_name,
        comment_type: 'team_emp'
    });
    newCommentModel.save(function (err, data) {
        //console.log(err);
        if (err) {
            console.log('error occured while saving comment', err);
            //return err;
        } else {
            console.log('New Mail received and saved as a comment to existing ticket');
        }

    });
    



//    if (params.attachTicketID) {
////        get_ticket_imageArray(params.attachTicketID).then(function (imageArray) {
////            console.log(imageArray);
////        })
//        //get_ticket_imageArray(params);
//    } else {
//
//        ticketModel.findOneAndUpdate(
//                {ticketID: params.ticketID}, {$set: {status: "Re-Open", img_Path: ticketArray}},
//                function (err, update) {
//                    if (err) {
//                        //res.status(500).json("Internal Database error");
//                        //res.send(err);
//                        //console.log('error occured while fetching ID');
//                    } else {
//                        console.log('ticket got updated as', update._id)
//                        if (update && update._id) {
//
////                    console.log('New Data saved as',{
////                        ticketID: params.ticketID,
////                        //tid: update._id,
////                        reportedBy: params.emp_name,
////                        reportedByEmail: params.emp_email,
////                        comment: params.comment,
////                        commentedByName: params.emp_name,
////                        comment_type: 'team_emp'
////                    });
//
//                        }
//                    }
//                });
//    }
};
exports.commentAddedByTeamToEmp = function (req, res) {
    var commentBody = req.body;
    console.log(commentBody);
    var newCommentModel = new commentModel({
        ticketID: commentBody.ticketID,
        tid: commentBody.tid,
        reportedBy: commentBody.reportedby,
        reportedByEmail: commentBody.reportedbyemail,
        comment: commentBody.comment,
        commentedByID: commentBody.userid,
        commentedByName: commentBody.username,
        comment_type: 'team_emp'
    });
    //console.log('comment detail - req ticketID:',req.body.ticketID);
    // console.log('comment detail - ticketID:',commentBody.ticketID);
    newCommentModel.save(function (err, data) {
        //console.log(err);
        if (err) {
            //console.log('error occured while saving comment', err);
            res.status(400);
            return res.json({msg: 'comment is not able to save.'});
        } else {
            // console.log('comment saved success',commentBody);
            if (commentBody.notifyEmp === true) {
                var subject = '#' + commentBody.ticketID + ' - comment is added by ' + commentBody.username;
                var params = {
                    comment: commentBody.comment,
                    commentedBy: commentBody.username,
                    ticketID: commentBody.ticketID
                };
                mailer.mailerService(commentBody.reportedbyemail, subject, params, 'template-comment');
            }
            //mailer.mailerService(req.body.email, 'Help Desk Reset Password', content);

            res.status(200);
            res.json(data);
        }

    });
};
exports.getComments = function (tid, res) {
    //console.log('getComments.........:', tid);
    commentModels.find({ticketID: tid}, function (err, comments) {
        if (err) {
            console.log("error", err);
            return res.status(500).json("Internal Database error");
        } else {
            res.status(200).send(comments);
        }
    });
};

exports.ticketOwnerUpdate = function (req, res) {
    //console.log('ticketOwnerUpdate..............');
    var recID = req.body.recID;
    var ownerid = req.body.ownerid;
    var msg = req.body.msg;
//    console.log('rec ID received', recID);
//    console.log('ownership ID received', ownerid);

    ticketModel.findByIdAndUpdate({_id: recID},
            {
                $set:
                        {
                            status: 'Open',
                            ownerid: ownerid,
                            ownershipDate: Date.now()
                        },
                $push: {'activityLogs': req.body.msg}
            },
            function (err, updated) {
                if (err) {
                    console.log("error", err);
                    // return res.status(500).json("Internal Database error");
                } else {
                    console.log("Ownership updated... ");
                    // res.status(200).send(updated);
                    res.status(200);
                    res.send({success: true, msg: 'Ownership has been updated.'});
                }
            });
};


//exports.ticketFieldUpdate = function (req, res) {
//    //console.log('getComments.........:', tid);
//    //console.log('request received', req);
//    var ticketID = req.ticketID;
//    var key = req.key;
//    var value = req.value;
//    var updateValue = {};
//    updateValue[key] = value;
//    ticketModel.findOneAndUpdate({ticketID: ticketID}, {$set: updateValue}, function (err, update) {
//        //ticketModel.find({ticketID: ticketID}, function (err, update) {
//        if (err) {
//            console.log(err);
//            res.status(500).json("Internal Database error");
//        } else {
//            //console.log('value updated', update);
//            if (update.length <= 0) {
//                res.send("Invalid Ticket Number!");
//            } else {
//
////                ticketModel.findByIdAndUpdate({_id: update[0]._id},
////                        { $set:updateValue}, function (err, updated) {
////                    if (err) {
////                        res.send(err);
////                    } else {
////                        console.log('updated value',updated);
//////                        if (res.statusCode == 200) {
//////                            console.log('updated');
//////                            //console.log("inside");
////////                            var hostName = req.headers.host;
////////                            var ticketID = req.query.ticketID;
////////                            var complUrl = "http://" + hostName + "/api/ticketsRelated/ticket-detail" + "?ticketID=" + ticketID;
////////
////////                            request.get({url: complUrl}, function optionalCallback(err, httpResponse, body) {
////////                                if (err) {
////////                                    return console.error('upload failed:', err);
////////                                }
////////                                res.send(body);
////////                            });
//////                        }
////                    }
////                    ;
////                });
//            }
//            ;
//        }
//        ;
//    });
//};


//    ticketModel.find({ticketID: req.query.ticketID}, function (err, update) {
//        if (err) {
//            res.status(500).json("Internal Database error");
//        } else {
//            if (update.length <= 0) {
//                console.log('invalid ticket number');
//                res.send("Invalid Ticket Number!");
//            } else {
//                ticketModel.findByIdAndUpdate({_id: update[0]._id},
//                        {
//                            $set: {
//                                tat_time: req.query.tat_time,
//                                assign_to: req.query.assign_to,
//                                status: req.query.status,
//                                priority: req.query.priority,
//                                issue_type_cat_1: req.query.issue_type_cat_1,
//                                issue_type_cat_2: req.query.issue_type_cat_2,
//                                issue_type_cat_3: req.query.issue_type_cat_3,
//                                closedDate: req.query.closedDate
//                            },
//                            $push: {'activityLogs': req.query.activityLogs}
//                        }, function (err, updated) {
//                    if (err) {
//                        res.send(err);
//                    } else {
//                        if (res.statusCode == 200) {
//
//                            //console.log("inside");
////                            var hostName = req.headers.host;
////                            var ticketID = req.query.ticketID;
////                            var complUrl = "http://" + hostName + "/api/ticketsRelated/ticket-detail" + "?ticketID=" + ticketID;
////
////                            request.get({url: complUrl}, function optionalCallback(err, httpResponse, body) {
////                                if (err) {
////                                    return console.error('upload failed:', err);
////                                }
////                                res.send(body);
////                            });
//
//                        }
//                    }
//                    ;
//                });
//            }
//            ;
//        }
//        ;
//    });