//
//
//var Member = require('../models/mailListnerModels');
//var Tickets = require('mongoose').model('mailListnerModel');
//
////exports.addMember = function (req, res) {
////    var memberBody = req.body;
////    memberBody.incidentID = generateIncId();
////    //  memberBody.reportedDate = generateDate('reported');
////    var pwd = generatePassword(10, true);
////    var newUser = new User({
////        email: memberBody.email,
////        password: pwd
////    });
////    newUser.save(function (err) {
////        console.log('New User has been created now entered to into the saved block');
////        if (err) {
////            return res.json({success: false, msg: 'Username already exists.'});
////        } else {
////            Members.create(memberBody, function (err, data) {
////                if (err) {
////                    if (err.toString().indexOf('E11000') > -1) {
////                        err = new Error('Duplicate Member');
////                    }
////                    res.status(400);
////                    return res.json({reason: err.toString()});
////                } else {
////                    console.log('Data added content',data);
////                    var content = "Your account has been registered. Please login using below credentials Email ID:" + memberBody.email + " Password: " + pwd;
////                    mailer.mailerService(memberBody.email, 'Help Desk login credentials', content);
////                    res.status(200);
////                    res.json(data._id);
////
////                    Members.findOneAndUpdate({'email': memberBody.email}, payLoad, {upsert: true}, function (err, doc) {
////                        if (err)
////                            return res.status(500).json(err);
////                        console.log(doc);
////                        res.status(200);
////                        res.json(data);
////                        //res.status(200).json(doc);
////                    });
////
////                    // save the user
////                }
////            });
////        }
////
////    });
////}
//
//
//
////console.log('generated password ',generatePassword(10,true));
//
//
////var generateIncId = function () {
////    var date = new Date();
////    var incId = "IM" + date.getFullYear().toString() + date.getDate().toString() + (date.getMonth() + 1).toString() + date.getHours().toString() + date.getMinutes().toString() + date.getSeconds().toString();
////    return incId;
////}
//
//exports.getTicketById = function (incId, res) {
//    console.log('Ticket ID received',incId);
//    Tickets.find({ticketID: incId}, function (err, details) {
//        if (err) {
//            console.log("error");
//            return res.status(500).json("Internal Database error");
//        };
//        console.log('details found as ',details)
//        res.status(200).json(details[0]);
//    });
//
//}
//
//exports.updateMember = function (payLoad, res) {
//    Tickets.findOneAndUpdate({'incidentID': payLoad.incidentID}, payLoad, {upsert: true}, function (err, doc) {
//        if (err)
//            return res.status(500).json(err);
//        console.log(doc);
//        res.status(200).json(doc);
//    });
//}
//exports.ticketsList = function (res) {
//    Tickets.find()
//            .limit(100)
//            .exec(function (err, docs) {
//                if (err)
//                    return res.status(500).json("Internal Server Error");
//                //console.log('docs resuls at server',docs);
//                res.status(200).json(docs);
//            });
////.where('status').nin(['Closed', 'Rejected'])
////            .sort({reportedDate: '-1'})
////            .where('incidentType').equals('Defect')
////            .select('incidentID title application status')
//}