/**
 * Created by CGI on 07/12/2016.
 */

var Member = require('../models/members');
var Members = require('mongoose').model('Member');
var generatePassword = require("password-generator");
var User = require('../models/member-auth.js');
var mailer = require('./mailer.js');
exports.addMember = function (req, res) {
    var memberBody = req.body;
    var pwd = generatePassword(10, true);
    var newUser = new User({
        email: memberBody.email,
        password: pwd
    });
    newUser.save(function (err, data) {
        if (err) {
            //console.log(err);
            res.status(400);
            return res.json({msg: 'User email already exists.'});
        } else {
            var newMemberID = data._id;
            //console.log(memberBody);
            Members.create(memberBody, function (err, data) {
                if (err) {
                    User.findByIdAndRemove(newMemberID, {},
                            function (err, obj) {
                                if (err) {
                                    console.log('error occured while removing user');
                                } else {
                                    console.log('user login details rolled backed');
                                }
                            }
                    );
                    console.log(err);
                    res.status(400);
                    return res.json({msg: 'Employee ID already exists '});
                } else {
                    //console.log('Data added content',data);
                    //var content = "Your account has been registered. Please login using below credentials Email ID:" + memberBody.email + " Password: " + pwd;
                    var params={
                        email_ID:memberBody.email,
                        pwd : pwd
                    };
                    mailer.mailerService(memberBody.email, 'Help Desk login credentials', params,'template-newmember');
                    var profileID = data._id;
                    User.findByIdAndUpdate(newMemberID, {
                        $set: {profileRef: profileID}
                    },
                            function (err, updatedData) {
                                if (err) {
                                    res.send(err);
                                    //console.log(err);
                                } else {
                                    //res.send(tank);
                                    console.log(updatedData);
                                    res.status(200);
                                    res.json(memberBody.email);
                                    //console.log(updatedData);
                                }
                            });
                    // save the user
                }
            });
        }

    });
};
//var generateIncId = function () {
//    var date = new Date();
//    var incId = "IM" + date.getFullYear().toString() + date.getDate().toString() + (date.getMonth() + 1).toString() + date.getHours().toString() + date.getMinutes().toString() + date.getSeconds().toString();
//    return incId;
//}
exports.getMemberById = function (incId, res) {
    //console.log('member ID received',incId);
    Members.find({_id: incId}, function (err, details) {
        if (err) {
            console.log("error");
            return res.status(500).json("Internal Database error");
        }
        ;
        //console.log('details found as ',details)
        res.status(200).json(details[0]);
    });

}
exports.updateMember = function (payLoad, res) {
    Members.findOneAndUpdate({'incidentID': payLoad.incidentID}, payLoad, {upsert: true}, function (err, doc) {
        if (err)
            return res.status(500).json(err);
        //console.log(doc);
        res.status(200).json(doc);
    });
}
exports.membersList = function (res) {
    Members.find()
            .limit(100)
            .exec(function (err, docs) {
                if (err)
                    return res.status(500).json("Internal Server Error");
                res.status(200).json(docs);
            });

}
exports.updateMemberinfo = function (body, res) {
    console.log("update Member info called");
    Members.findOneAndUpdate({email: body.email},
            {$set: {accessRole: body.accessRole}},
            function (err, details) {
                if (err) {
                    //console.log("user details not found", err);
                    res.status(500);
                    res.json({success: false, msg: err});
                } else {
                    //console.log("Access Role is updated....");
                    res.status(200);
                    res.json({success: true, msg: 'User profile has been updated'});
                }
            });

}


//                    Members.findOneAndUpdate({'email': memberBody.email}, payLoad, {upsert: true}, function (err, doc) {
//                        if (err)
//                            return res.status(500).json(err);
//                        //console.log(doc);
//                        res.status(200);
//                        res.json(data);
//                        //res.status(200).json(doc);
//                    });
//console.log('generated password ',generatePassword(10,true));


//.where('status').nin(['Closed', 'Rejected'])
//            .sort({reportedDate: '-1'})
//            .where('incidentType').equals('Defect')
//            .select('incidentID title application status')