var nodemailer = require('nodemailer');
//var mailConfig = require('../config/config')['mailListener'];
var mailerConfig=require('../config/config')['mailer'];
var userName = encodeURI(mailerConfig.username);
var userpwd = mailerConfig.password;
var smtp_server = mailerConfig.smtpHost;
var transporter = nodemailer.createTransport('smtp://' + userName + ':' + userpwd + '@' + smtp_server);
var EmailTemplates = require('swig-email-templates');
var templates = new EmailTemplates();


exports.mailerService = function (empEmail, title, params, template) {
    if (!template) {
        template = 'plain-text';
    }
    if(mailerConfig.turnOff===true){
        console.log('Mailer is turned off');
        return false;
    }
    console.log('received params in mailer',params);
    templates.render('../../../server/config/email-templates/' + template + '.html', params, function (err, html, text, subject) {
        if (!err) {
            var mailOptions = {
                from: 'Admin <' + mailerConfig.username + '>', // sender address
                to: empEmail, // list of receivers
                subject: title, // Subject line
                //text: 'Hello world ', // plaintext body
                html: html // html body
            };
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    return console.log(error);
                } else {
                    console.log('Mail Has Been sent to : ' + empEmail + 'with info' + info);
                    //console.log('Mail Status: ' + info.response);
                }
            });
        }else{
            console.log('Some Error occured while fetching Mail Template',err);
        }

    });
}